/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function ClearUsuarios(){
    document.getElementById("frmNuevoUsuario:nombre").value = "";
    document.getElementById("frmNuevoUsuario:apellido").value = "";
    document.getElementById("frmNuevoUsuario:direccion").value = "";
    document.getElementById("frmNuevoUsuario:telefono").value = "";
    document.getElementById("frmNuevoUsuario:nickname").value = "";
    document.getElementById("frmNuevoUsuario:password").value = ""; 
    document.getElementById("frmNuevoUsuario:repeatPassword").value = "";
}

