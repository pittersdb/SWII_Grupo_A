/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function ClearPacientes(){
    document.getElementById("frmNuevoPaciente:nombres").value = "";
    document.getElementById("frmNuevoPaciente:apellidos").value = "";
    document.getElementById("frmNuevoPaciente:direccion").value = "";
    document.getElementById("frmNuevoPaciente:inputFechaNacimiento").value = "";
    document.getElementById("frmNuevoPaciente:lugar_procedencia").value = "";
    document.getElementById("frmNuevoPaciente:sexo").value = "";
    document.getElementById("frmNuevoPaciente:ci").value = "";
}