/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function ClearMediciones(){
    document.getElementById("tabViewAgenda:frmMediciones:peso").value = "";
    document.getElementById("tabViewAgenda:frmMediciones:estatura").value = "";
    document.getElementById("tabViewAgenda:frmMediciones:glucosa").value = "";
    document.getElementById("tabViewAgenda:frmMediciones:presion_arterial").value = "";
}
