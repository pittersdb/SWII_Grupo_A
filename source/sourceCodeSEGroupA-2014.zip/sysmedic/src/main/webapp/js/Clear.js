/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function ClearLotes(){
    document.getElementById("formIngMedicinas:inputPrecio").value = "";
    document.getElementById("formIngMedicinas:inputCantidad").value = "";
}

function ClearNuevoMedicamento(){
    document.getElementById("formNuevoMedicamento:nombre_medicina").value = "";
    document.getElementById("formNuevoMedicamento:descripcion_medicina").value = "";
}