/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function ClearFactura(){
    document.getElementById("frmFactura:nombres").value = "";
    document.getElementById("frmFactura:apellidos").value = "";
    document.getElementById("frmFactura:ruc").value = "";
    document.getElementById("frmFactura:telefono").value = "";
    document.getElementById("frmFactura:direccion").value = "";
    document.getElementById("frmFactura:iva").value = "";
    document.getElementById("frmFactura:descuento").value = "";
    document.getElementById("frmFactura:total").value = "";
    document.getElementById("frmFactura:fechaPago").value = "";
    document.getElementById("frmFactura:observacion").value = "";
    
}

